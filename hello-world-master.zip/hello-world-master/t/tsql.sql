DECLARE @message varchar(128)
SELECT  @message = 'Hello World'
PRINT   @message
