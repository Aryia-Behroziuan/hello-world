function Hello() {
  return <h1>Hello World</h1>;
}

React.render(<Hello />, document.body);
