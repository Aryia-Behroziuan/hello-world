ксива.малява("Hello World") нах
