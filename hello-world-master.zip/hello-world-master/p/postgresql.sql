SELECT 'Hello World' AS hello_message;
